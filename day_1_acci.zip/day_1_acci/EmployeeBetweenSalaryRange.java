package day_1_acci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class EmployeeBetweenSalaryRange {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter min sal: ");
		double minSal = sc.nextDouble();
		System.out.println("Enter max sal: ");
		double maxSal = sc.nextDouble();
		
		try {
			
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/firstdb",
					"root",
					"siddhu"
			);
			
			String query = "SELECT * FROM emp WHERE sal BETWEEN ? AND ?";
			
			PreparedStatement ps = con.prepareStatement(query);
			ps.setDouble(1,  minSal);
			ps.setDouble(2,  maxSal);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				System.out.println(
						rs.getInt("empno") + " " 
						+ rs.getString("ename") + " " 
						+ rs.getDouble("sal")
				);
			}
			
			con.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		

	}

}
