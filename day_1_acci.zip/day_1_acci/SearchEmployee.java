package day_1_acci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class SearchEmployee {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter Employee Id: ");
		int empid = sc.nextInt();
		
		try {
			
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/firstdb",
					"root",
					"siddhu"
			);
			
			String query = "SELECT * FROM emp WHERE empno = ?";
			
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setInt(1,  empid);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				System.out.println("Employee Found");
				
				System.out.println(
						rs.getInt("empno") + " "
						+ rs.getString("ename") + " "
						+ rs.getString("job") + " " 
						+ rs.getDouble("sal")
				);
			}
			else {
				System.out.println("Employee Does Not Exist");
			}
			
			con.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
