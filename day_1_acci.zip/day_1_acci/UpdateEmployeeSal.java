package day_1_acci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UpdateEmployeeSal {

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/firstdb";
        String user = "root";
        String password = "siddhu";
        
        int empId = 7369;
        double newSalary = 2000;
        
        try {
        	Connection con = DriverManager.getConnection(url, user, password);

            String updateQuery = "UPDATE emp SET sal=? WHERE empno=?";

            PreparedStatement ps = con.prepareStatement(updateQuery);

            ps.setDouble(1, newSalary);
            ps.setInt(2, empId);

            int rows = ps.executeUpdate();
            
            if(rows > 0)
                System.out.println("Salary Updated");

            String verifyQuery = "SELECT empno,ename,sal FROM emp WHERE empno=?";

            PreparedStatement ps2 = con.prepareStatement(verifyQuery);

            ps2.setInt(1, empId);

            ResultSet rs = ps2.executeQuery();
            
            while(rs.next()) {
                System.out.println(
                        rs.getInt("empno") + " "
                        + rs.getString("ename") + " "
                        + rs.getDouble("sal")
                );
            }

            con.close();
        }
        catch(Exception e) {
        	e.printStackTrace();
        }

	}

}
