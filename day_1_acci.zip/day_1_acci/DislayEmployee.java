package day_1_acci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DislayEmployee {

	public static void main(String[] args) {
		
		 	String url = "jdbc:mysql://localhost:3306/firstdb";
	        String user = "root";
	        String password = "siddhu";
	        
	        try {
	            Connection con = DriverManager.getConnection(url, user, password);

	            String sql = "SELECT * FROM emp";

	            Statement st = con.createStatement();

	            ResultSet rs = st.executeQuery(sql);

	            while(rs.next()) {

	                System.out.println(
	                        rs.getInt("empno") + " "
	                        + rs.getString("ename") + " "
	                        + rs.getString("job") + " "
	                        + rs.getDouble("sal")
	                );
	            }

	            con.close();

	        } catch(Exception e) {
	            e.printStackTrace();
	        }

	}

}
