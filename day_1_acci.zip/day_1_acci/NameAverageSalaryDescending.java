package day_1_acci;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class NameAverageSalaryDescending {
	
	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/firstdb";
        String user = "root";
        String password = "siddhu";
        
        try {
        	
        	Connection con = DriverManager.getConnection(url, user, password);
        	
        	String query = 
        			"SELECT d.dname, AVG(e.sal) avg_salary " +
                            "FROM emp e JOIN dept d " +
                            "ON e.deptno=d.deptno " +
                            "GROUP BY d.dname " +
                            "ORDER BY avg_salary DESC";

                    Statement st = con.createStatement();

                    ResultSet rs = st.executeQuery(query);
                    
                    while(rs.next()) {

                        System.out.println(
                                rs.getString("dname") + " : "
                                + rs.getDouble("avg_salary")
                        );
                    }

                    con.close();
        }
        catch(Exception e) {
        	e.printStackTrace();
        }
	}
}
