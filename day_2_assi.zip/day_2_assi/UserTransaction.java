package day_2_assi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class UserTransaction {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		try {
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/firstdb",
					"root",
					"siddhu"
			);
			
			con.setAutoCommit(false);
			
			System.out.print("UID : ");
            int uid = sc.nextInt();
            sc.nextLine();

            System.out.print("Name : ");
            String name = sc.nextLine();

            System.out.print("Email : ");
            String email = sc.nextLine();

            System.out.print("Contact : ");
            String contact = sc.nextLine();

            System.out.print("City : ");
            String city = sc.nextLine();

            System.out.print("SSC Marks : ");
            double ssc = sc.nextDouble();

            System.out.print("HSC Marks : ");
            double hsc = sc.nextDouble();

            System.out.print("Graduation Marks : ");
            double grad = sc.nextDouble();
            
            PreparedStatement ps1 = con.prepareStatement(
            		
            		"INSERT INTO userinfo VALUES(?,?,?,?,?)"
            );
            		
            		ps1.setInt(1,  uid);
            		ps1.setString(2,  name);
            		ps1.setString(3,  email);
            		ps1.setString(4, contact);
            		ps1.setString(5,  city);
            		
            		ps1.executeUpdate();
            		
            		con.commit();
            		
            		System.out.println("Transaction Successful");

                    con.close();
            		
            
		}
		catch(Exception e) {
			 System.out.println("Transaction Failed");
			 e.printStackTrace();
		}

	}

}
