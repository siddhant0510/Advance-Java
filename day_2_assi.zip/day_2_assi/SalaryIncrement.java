package day_2_assi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SalaryIncrement {

	public static void main(String[] args) {
		
		try {
			
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/firstdb", 
					"root", 
					"siddhu"
			);
			
			Statement st = con.createStatement(
				ResultSet.TYPE_SCROLL_SENSITIVE,
				ResultSet.CONCUR_UPDATABLE
			);
			
			ResultSet rs = st.executeQuery(
					"SELECT empno, ename, sal FROM emp"
			);
			
			 while(rs.next()) {

	                double sal = rs.getDouble("sal");

	                if(sal < 10000)
	                    sal += sal * 0.02;

	                else if(sal < 25000)
	                    sal += sal * 0.05;

	                else if(sal < 50000)
	                    sal += sal * 0.08;

	                else
	                    sal += sal * 0.10;

	                rs.updateDouble("sal", sal);
	                rs.updateRow();
	            }
			 
			 System.out.println("Salary Updated Successfully");

	            con.close();

		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
