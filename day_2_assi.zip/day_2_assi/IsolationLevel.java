package day_2_assi;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;

public class IsolationLevel {

	public static void main(String[] args) {
		
		try {
			
			Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/firstdb",
                    "root",
                    "siddhu");
			
			int level = con.getTransactionIsolation();
			
			System.out.println(level);
			
			System.out.println("Curent isolation level:");
			
			switch(level) {
			
			case Connection.TRANSACTION_READ_UNCOMMITTED:
                System.out.println("READ_UNCOMMITTED");
                break;
                
				case Connection.TRANSACTION_READ_COMMITTED:
                    System.out.println("READ_COMMITTED");
                    break;

                case Connection.TRANSACTION_REPEATABLE_READ:
                    System.out.println("REPEATABLE_READ");
                    break;

                case Connection.TRANSACTION_SERIALIZABLE:
                    System.out.println("SERIALIZABLE");
                    break;
			}
			
			DatabaseMetaData dbmd = con.getMetaData();
			
			System.out.println("\nSupported Levels:");
			
			 System.out.println(
	                    "READ_UNCOMMITTED : " +
	                    dbmd.supportsTransactionIsolationLevel(
	                            Connection.TRANSACTION_READ_UNCOMMITTED));

	            System.out.println(
	                    "READ_COMMITTED : " +
	                    dbmd.supportsTransactionIsolationLevel(
	                            Connection.TRANSACTION_READ_COMMITTED));

	            System.out.println(
	                    "REPEATABLE_READ : " +
	                    dbmd.supportsTransactionIsolationLevel(
	                            Connection.TRANSACTION_REPEATABLE_READ));

	            System.out.println(
	                    "SERIALIZABLE : " +
	                    dbmd.supportsTransactionIsolationLevel(
	                            Connection.TRANSACTION_SERIALIZABLE));

	            con.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
